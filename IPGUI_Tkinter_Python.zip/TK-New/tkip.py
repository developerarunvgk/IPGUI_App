import tkinter as tk
from tkinter import ttk
from tkinter import * 
from ipd1 import sc
# this is the function called when the button is clicked
def btnClickFunction():
	print('clicked')
	a=sc();
	Label(root, text=a, bg='#32CD32', font=('arial', 16, 'normal')).place(x=216, y=26)




root = Tk()

# This is the section of code which creates the main window
root.geometry('598x160')
root.configure(background='#32CD32')
root.title('IP Checker')


# This is the section of code which creates the a label


# This is the section of code which creates a button
Button(root, text='MyPublicIp', bg='#EE00EE', font=('arial', 16, 'normal'), command=btnClickFunction).place(x=222, y=72)


root.mainloop()
