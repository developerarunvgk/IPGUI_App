import urllib
import requests
#from bs4 import BeautifulSoup
#https://stackoverflow.com/questions/9481419/how-can-i-get-the-public-ip-using-python2-7
#https://stackoverflow.com/questions/36357369/how-to-get-the-ip-address-of-the-url-in-requests-module-in-python-3-5-1
#https://stackoverflow.com/questions/22492484/how-do-i-get-the-ip-address-from-a-http-request-using-the-requests-library
#https://izziswift.com/python-requests-print-entire-http-request-raw/
#https://stackoverflow.com/questions/16923898/how-to-get-the-raw-content-of-a-response-in-requests-with-python

def sc():	
	#quote_page="http://127.0.0.1:8000/"
	quote_page="https://www.wikipedia.org/"
	#quote_page="https://www.dw.com/en/top-stories/s-9097"
	page = requests.get(quote_page,stream=True)#For Sock to work well
	#print(dir(page))
	print("IP Details")
	#print(page.headers)
	print("Public Ip is "+str(page.headers["X-Client-IP"]))
	return("Public Ip is "+str(page.headers["X-Client-IP"]))
	#print("-")
	#print(page.request.headers)
	#print(page.request.body)
	soc=page.raw._connection.sock
	#print(dir(soc))
	print("Site:IP && Client Ip")
	print(page.raw._connection.sock.getsockname())
	print(page.raw._connection.sock.getpeername())
	#print(dir(page.raw))

	return "HI"
#a=sc();
#print("Done")